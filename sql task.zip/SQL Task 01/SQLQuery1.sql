/*Load data from the SalesOrderHeader table in the AdventureWorks database to the newly created database (Hint: Use Insert into) */
select *into New_Database.dbo.Tabe_l1 from AdventureWorks2019.Sales.SalesOrderHeader;
select *from New_Database_dbo.Tabe_l1;
/*Recreate the Sales Territory table using create and insert statements */
select *from AdventureWorks2019.Sales.SalesTerritory;
Create TABLE Re_SalesTerritory(
   TerritoryID INT,
   Name VARCHAR(30),
   CountryRegionCode VARCHAR(10),
   Groups VARCHAR(20),
   SalesYTD VARCHAR(20),
   SalesLastYear VARCHAR(20),
   CostYTD VARCHAR(10),
   CostLastYear VARCHAR(20),
   rowguid VARCHAR(50),
   ModifiedDate DATETIME,
   );
   select *from dbo.Re_SalesTerritory;
   insert into Re_SalesTerritory select * from AdventureWorks2019.Sales.SalesTerritory;
   select *from dbo.Re_SalesTerritory;

   /*Query the table for records with Territory IDs from 1 to 4 using a single filter clause */
   select *from New_Database.dbo.ReSalesTerritory
   Where TerritoryID Between 1 and 4;
   
   /*Query the table for records with the Order date from 1st of Jan, 2012 to 31st Mat,2012*/
   Select *from AdventureWorks2019.Sales.SalesOrderHeader
   Where OrderDate Between '2012-01-01 00:00:00:000' AND '2012-05-31 00:00:00:000';
   /*Query the table for records having Territories starting with 'South' */
   Select *from AdventureWorks2019.Sales.SalesTerritory
   Where Name LIKE 'South%';
   /*Query the Total amount due for each Territory */
   select DISTINCT Name,AVG(TotalDue) AS Average_TotalDue
   from AdventureWorks2019.Sales.SalesOrderHeader
   inner join AdventureWorks2019.Sales.SalesTerritory on salesorderheader.TerritoryID = SalesTerritory.TerritoryID
   group by Name;
  
  --Create a view that displays the sub total amount for each territory that has the value greater than 25000
   
   Create VIEW Sub_Total AS 
   Select  DISTINCT name, AVG(SubTotal) as Subtotal
   from AdventureWorks2019.Sales.SalesOrderHeader
   inner join AdventureWorks2019.Sales.SalesTerritory on salesorderheader.TerritoryID = SalesTerritory.TerritoryID

   where SubTotal>25000
   group by Name;
   select *from Sub_Total;
   Select *from AdventureWorks2019.Sales.SalesOrderHeader;

   --Create a stored procedure that returns the list of Sale Orders and its details for a specific date given as a parameter */
   
   CREATE PROCEDURE ListofSaleOrders @ShipDate datetime
   AS
   SELECT * FROM AdventureWorks2019.Sales.SalesOrderHeader
   WHERE ShipDate = @ShipDate;
   GO
   EXEC ListofSaleOrders @ShipDate = '2011-06-07 00:00:00:000';
   
   select *from AdventureWorks2019.Sales.SalesOrderHeader;