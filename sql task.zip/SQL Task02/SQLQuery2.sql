select *from AdventureWorks2019.Sales.SalesOrderHeader;
select *from AdventureWorks2019.Sales.SalesTerritory;
select *from New_Database.dbo.ReSalesTerritory;

/* query to return the even rows of the table you've created */

SELECT TerritoryID,Name,CountryRegionCode,SalesLastYear 
FROM (
    SELECT *, Row_Number() OVER(ORDER BY TerritoryID, SalesLastYear) AS RowNumber 
           
    FROM AdventureWorks2019.Sales.SalesTerritory
) t
WHERE t.RowNumber % 2 = 0
/*Display the total due amount by territories considering only the even order IDs */
select  TerritoryID, AVG(TotalDue) AS AVERAGE_TotalDue
from (
     select *,Rank() OVER(ORDER BY TerritoryID, TotalDue) AS Rank_number
	 FROM AdventureWorks2019.Sales.SalesOrderHeader
)t
WHERE t.rank_number % 2 = 0
group by TerritoryID;

/*Delete the transactions from the SalesOrderHeader table for the territories that have more than 200 salesPersons involved*/

select *into New_Database.dbo.Transactions from AdventureWorks2019.Sales.SalesOrderHeader;
select *from New_Database.dbo.Transactions;
use New_Database
GO
BEGIN Tran
Delete from Transactions
where SalesPersonID>200
rollback
select *from New_Database.dbo.Transactions;



--Display all the transactions along with the territory name as a separate column without any joins. Hint: You can hardcode values(Case) */

SELECT SalesOrderID, AccountNumber,CustomerID,SalesPersonID,SubTotal,TotalDue,Name,
CASE WHEN Name like 'NORTH%' THEN 'The Territory name starts with North'
WHEN Name like 'south%' THEN 'The Territory name starts with South'
ELSE 'The Territory Name is Other than North and South'
END AS Name
FROM AdventureWorks2019.Sales.SalesOrderHeader,AdventureWorks2019.Sales.SalesTerritory;
--Create an index for any one of the tables 
CREATE INDEX Transaction_History
ON  AdventureWorks2019.Production.TransactionHistory (TransactionID, ProductID,Quantity);
--Display the list of transactions having the salesPerson from the territory 'NorthWest' 
select Name,OrderDate,SalesOrderNumber,CustomerID,SubTotal,TaxAmt,TotalDue
from AdventureWorks2019.Sales.SalesOrderHeader,AdventureWorks2019.Sales.SalesTerritory
where name = 'NorthWest';

--temperory table

CREATE table #temp1(TotalDue int not null,
                   name varchar(50) not null,
				   SalesPersonID varchar(50))
insert into #temp1
select TotalDue,name,SalesPersonID
from AdventureWorks2019.Sales.SalesOrderHeader,AdventureWorks2019.Sales.SalesTerritory
select *from #temp1 where name like 'north%';

create procedure Due_At_North
as 
select *from #temp1;
exec Due_At_North;

--loading to static table
select *into New_Database.dbo.static_table1 from #temp1;

--Truncate and drop
select *from New_Database.dbo.static_table1
truncate table #temp1;
drop table #temp1;


--Script out the schema and data of the table in Point 10 for it to be compatible to SQL Server 2014 

--Tasks->Generate Scripts->Advanced->Change to Server2014->Schema and data




